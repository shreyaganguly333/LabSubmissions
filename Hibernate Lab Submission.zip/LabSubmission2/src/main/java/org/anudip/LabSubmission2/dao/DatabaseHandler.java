package org.anudip.LabSubmission2.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.anudip.LabSubmission2.bean.Result;
import org.anudip.LabSubmission2.bean.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

//A class for managing Hibernate database sessions and configuration
public class DatabaseHandler {
	 private static final DatabaseHandler dbHandler2 = new DatabaseHandler();
	 
	// Hibernate SessionFactory for managing database sessions
	 private static SessionFactory sessionFactory;
	 
	 	// Private constructor to initialize Hibernate configuration
	    private DatabaseHandler() {
	        try {
	            // Load Hibernate properties from hibernate.properties
	            Properties properties = new Properties();
	            InputStream hibernatePropsStream = getClass().getClassLoader().getResourceAsStream("hibernate.properties");
	            if (hibernatePropsStream != null) {
	                properties.load(hibernatePropsStream);
	            } else {
	                throw new IOException("Unable to load hibernate.properties");
	            }

	            // Create a Hibernate configuration
	            Configuration config = new Configuration();
	            config.setProperties(properties);
	            config.addAnnotatedClass(Student.class);// Mention your entity class
	            config.addAnnotatedClass(Result.class);
	            
	            // Build the SessionFactory
	            sessionFactory = config.buildSessionFactory();
	        } catch (IOException e) {
	            
	        	// Handle or log the exception
	            e.printStackTrace();
	            throw new RuntimeException("Error initializing Hibernate configuration.");
	        }
	    }

	   public static DatabaseHandler getDatabaseHandler() {
	        return dbHandler2;
	    }

	    // Create a Hibernate session
	    public Session createSession() {
	        if (sessionFactory == null) {
	            throw new RuntimeException("Session factory is not initialized.");
	        }
	        return sessionFactory.openSession();
	    }

	    // Close a Hibernate session
	    public void closeSession(Session session) {
	        if (session != null && session.isOpen()) {
	            session.close();
	        }
	    }

	    // Close the SessionFactory
	    public void closeSessionFactory() {
	        if (sessionFactory != null && !sessionFactory.isClosed()) {
	            sessionFactory.close();

	      }
	 }//end of closeSessionFactory
}//End of DatabaseHandler class