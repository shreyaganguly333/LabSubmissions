package org.anudip.LabSubmission2.bean;

//Custom exception class to represent an exception when a student is not found
public class StudentNotFoundException extends RuntimeException{
	static final long serialVersionUID=1L;
	
	// Constructor that accepts a message to describe the exception
	public StudentNotFoundException(String message) {
    	super(message);
    }
}//end of StudentNotFoundException class