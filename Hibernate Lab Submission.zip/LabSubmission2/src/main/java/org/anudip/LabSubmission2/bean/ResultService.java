package org.anudip.LabSubmission2.bean;

//A class for calculating the grade based on student results
public class ResultService {
	
	// Method to calculate the grade based on the given result
	public static String gradeCalculation(Result result) {
        // Calculated the grade based on the given formula
        double totalScore = result.getHalfYearlyTotal() + result.getAnnualTotal();
        double percentage = (totalScore / 1000) * 100;
        
        // Determining the grade based on the percentage
        if (percentage >= 90) {
            return "E";
        } else if (percentage >= 75) {
            return "V";
        } else if (percentage >= 60) {
            return "G";
        } else if (percentage >= 45) {
            return "P";
        } else {
            return "F";
        }
    }//end of gradeCalculation 
}//end of ResultService Class