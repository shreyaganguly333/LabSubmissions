package org.anudip.LabSubmission2.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Student")

public class Student {//start of Student class
	// Primary key representing the student's roll number
    @Id
    @Column(name = "Roll_Number")
    private String rollNumber;
    
    // The name of the student
    @Column(name = "Student_Name")
    private String studentName;
    
    // The semester in which the student is enrolled
    @Column(name = "Semester")
    private String semester;

    // One-to-One relationship with the Result entity, representing student's result
    @OneToOne(fetch = FetchType.LAZY, targetEntity = Result.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Roll_Number")
    private Result studentResult;

    //Additional field to store the half-yearly total
    @Column(name = "Half_Yearly_Total")
    private double halfYearlyTotal;
    
    // Default constructor
    public Student() {
        super();
    }

    // Constructor with parameters, including the half-yearly total
    public Student(String rollNumber, String studentName, String semester, double halfYearlyTotal) {
        super();
        this.rollNumber = rollNumber;
        this.studentName = studentName;
        this.semester = semester;
        this.halfYearlyTotal = halfYearlyTotal;
    }
    
    // Getter and Setter methods for the fields

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public Result getStudentResult() {
        return studentResult;
    }

    public void setStudentResult(Result studentResult) {
        this.studentResult = studentResult;
    }

    public double getHalfYearlyTotal() {
        return halfYearlyTotal;
    }

    public void setHalfYearlyTotal(double halfYearlyTotal) {
        this.halfYearlyTotal = halfYearlyTotal;
    }
    
    // Override toString() method to provide a formatted string representation of the object

    @Override
    public String toString() {
        return String.format("%-5s %-20s %-5s %-2s", rollNumber, studentName, semester, studentResult);
        }
}//end of Student class