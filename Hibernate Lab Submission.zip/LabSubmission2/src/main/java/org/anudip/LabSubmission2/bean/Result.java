package org.anudip.LabSubmission2.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "result")
public class Result {//start of Result Class
    
	// Primary key representing the student's roll number
	@Id
    @Column(name = "roll_number")
    private String rollNumber;
	
	// The total marks for the half-yearly exam
    @Column(name = "half_yearly_total")
    private Double halfYearlyTotal;

    // The total marks for the annual exam
    @Column(name = "annual_total")
    private Double annualTotal;
    
    // The calculated grade based on the total marks
    @Column(name = "grade")
    private String grade;

    // Default constructor required by Hibernate
    public Result() {
        
    }
    // Constructor with parameters to initialize the result object
    public Result(String rollNumber, Double halfYearlyTotal, Double annualTotal) {
        this.rollNumber = rollNumber;
        this.halfYearlyTotal = halfYearlyTotal;
        this.annualTotal = annualTotal;
        this.grade = gradeCalculation(annualTotal + halfYearlyTotal);
    }

    // Getter method for rollNumber
    public String getRollNumber() {
        return rollNumber;
    }

    // Setter method for rollNumber
    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    // Getter method for halfYearlyTotal
    public Double getHalfYearlyTotal() {
        return halfYearlyTotal;
    }

    // Setter method for halfYearlyTotal
    public void setHalfYearlyTotal(Double halfYearlyTotal) {
        this.halfYearlyTotal = halfYearlyTotal;
    }

    // Getter method for annualTotal
    public Double getAnnualTotal() {
        return annualTotal;
    }

    // Setter method for annualTotal
    public void setAnnualTotal(Double annualTotal) {
        this.annualTotal = annualTotal;
    }

    // Getter method for grade
    public String getGrade() {
        return grade;
    }
       
    // Calculate the grade based on the total marks
    private String gradeCalculation(double totalMarks) {
        if (totalMarks >= 90) {
            return "E";
        } else if (totalMarks >= 75) {
            return "V";
        } else if (totalMarks >= 60) {
            return "G";
        } else if (totalMarks >= 45) {
            return "P";
        } else {
            return "F";		}
}
    // Override toString() method to provide a formatted string representation of the object
    @Override
    public String toString() {
        return String.format("%-5s %-20s %-20s  %-5s", rollNumber, halfYearlyTotal, annualTotal, grade);
    }
}//end of Result Class