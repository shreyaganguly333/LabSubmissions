package org.anudip.LabSubmissions.application;

import java.util.Scanner;
import org.anudip.LabSubmissions.bean.EssentialCommodityException;
import org.anudip.LabSubmissions.bean.GradeMismatchException;
import org.anudip.LabSubmissions.bean.PriceException;
import org.anudip.LabSubmissions.bean.Product;
import org.anudip.LabSubmissions.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;

//Declaring the ProductEntry class to take inputs from user
public class ProductEntry {//Start of ProductEntry Class
	
	public static void main(String[] args)throws Exception {//end of Void main
		
		// Creating a Scanner for user input
		Scanner scanner = new Scanner(System.in);
        try (scanner) {
        	
        	// Accept input for product details as a comma-separated string
            System.out.println("Hi User! Please Enter the Product Details in the format: (Product_Id,Product_Name,Purchase_Price,Sales_Price,Grade)");
            String stg = scanner.nextLine();
            String[] arr = stg.split(",");
            int id = Integer.parseInt(arr[0]);
            String name = arr[1];
            double purchasedPrice = Double.parseDouble(arr[2]);
            double salesPrice = Double.parseDouble(arr[3]);
            String grade = arr[4];
            String eCarry = "E";
            String nCarry = "N";

            try {
            	// Checking if sales price is lower than purchase price
                if (salesPrice < purchasedPrice) {
                    throw new PriceException("Uh no! Sales price must be higher than purchase price");
                }
                // Checking if the product grade is wrong
                else if (!(grade.equals(eCarry) || grade.equals(nCarry))) {
                    throw new GradeMismatchException("No! It is a Wrong grade");
                }
                // Checking if E graded product sales price is greater than 25% of purchase price
                else if (grade.equals(eCarry) && (salesPrice > purchasedPrice + (0.25 * purchasedPrice))) {
                    throw new EssentialCommodityException("User, E graded items sales price must be lesser than 25% of purchase price");
                }

                // Setting the values of the product
                Product product = new Product(id, name, purchasedPrice, salesPrice, grade);
                DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
                try (Session session = dbHandler.createSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.persist(product);
                    transaction.commit();
                } catch (Exception e) {
                    System.out.println("Error while saving product: " + e.getMessage());
                }
                } catch (PriceException pe) {
                System.out.println("PriceException: " + pe.getMessage());
                } catch (EssentialCommodityException ece) {
                System.out.println("EssentialCommodityException: " + ece.getMessage());
                } catch (GradeMismatchException ge) {
                System.out.println("GradeMismatchException: " + ge.getMessage());
                }
            // Displaying a message indicating that a new product has been added
            System.out.println("New Product Added");
        
        }//end of try block
	scanner.close();
	}//end of Void main

}//Start of ProductEntry Class