package org.anudip.LabSubmissions.bean;

//EssentialCommodityException class that extends the RuntimeException class
public class EssentialCommodityException extends RuntimeException{
	
	// A serialVersionUID to ensure version compatibility
	private static final long serialVersionUID = 1L;
	
	// Constructor that takes a message as a parameter
	public EssentialCommodityException(String message) {
		super(message);
	}
}//end of EssentialCommodityException class