package org.anudip.LabSubmissions.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//Declaring an entity class representing a Product
@Entity
@Table(name = "Product")
public class Product implements Comparable<Product> {//start of Product class
	// Declaring Entity field: Product Id, marked as the primary key
	@Id
    @Column(name = "Product_Id")
    private Integer productId;
	
	// Declaring Entity fields: Product Name, Purchase Price, Sales Price, and Grade
    @Column(name = "Product_Name")
    private String productName;

    @Column(name = "Purchase_Price")
    private Double purchasedPrice;

    @Column(name = "Sales_Price")
    private Double salesPrice;

    @Column(name = "Grade")
    private String grade;
    
    // Default constructor required by Hibernate
    public Product() {
        // Default constructor required by Hibernate
    }
    
    // Parameterized constructor to initialize Product object
    public Product(Integer productId, String productName, Double purchasedPrice, Double salesPrice, String grade) {
        this.productId = productId;
        this.productName = productName;
        this.purchasedPrice = purchasedPrice;
        this.salesPrice = salesPrice;
        this.grade = grade;
    }
        
    // Getters and setters for all fields
    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getPurchasedPrice() {
		return purchasedPrice;
	}

	public void setPurchasedPrice(Double purchasedPrice) {
		this.purchasedPrice = purchasedPrice;
	}

	public Double getSalesPrice() {
		return salesPrice;
	}

	public void setSalesPrice(Double salesPrice) {
		this.salesPrice = salesPrice;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}
    
	// Implementing Comparable interface for sorting based on productId
    @Override
    public int compareTo(Product other) {
        return this.productId - other.productId;
    }

    // Customized string representation for Product objects
	@Override
    public String toString() {
        return String.format("%-5s %-20s %-10s %-10s %-5s",
                productId, productName, purchasedPrice, salesPrice, grade);
    }
}//End of Product class