package org.anudip.LabSubmissions.bean;

//PriceException class that extends the RuntimeException class
public class PriceException extends RuntimeException {
	
	// A serialVersionUID to ensure version compatibility
	private static final long serialVersionUID = 1L;
	
	// Constructor that takes a message as a parameter
	public PriceException(String message) {
		super(message);
	}
}//end of PriceException class
