package org.anudip.LabSubmissions.bean;

//GradeMismatchException class that extends the RuntimeException class
public class GradeMismatchException extends RuntimeException{
	
	// A serialVersionUID to ensure version compatibility
	private static final long serialVersionUID = 1L;

	// Constructor that takes a message as a parameter
	public GradeMismatchException(String message) {
		super(message);
	}
}//end of GradeMismatchException class
