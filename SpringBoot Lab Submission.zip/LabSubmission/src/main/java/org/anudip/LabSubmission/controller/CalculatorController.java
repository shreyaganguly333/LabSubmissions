package org.anudip.LabSubmission.controller;

import org.anudip.LabSubmission.exception.OperatorException;
import org.anudip.LabSubmission.service.CalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
@RestController
//Using Controller Annotation
@Controller
public class CalculatorController {
	
	//Using Autowired Annotation
    @Autowired
    private CalculatorService calService;

    // This method handles GET requests to the "/calculator" URL
    @GetMapping("/calculator")
    public ModelAndView showCalculatorEntryPage() {
        // Return a ModelAndView to display the calculator entry page
        return new ModelAndView("calculatorEntry");
    }

    // This method handles POST requests to the "/calculate" URL
    @PostMapping("/calculator")
	public ModelAndView showCalculatorViewPage(@RequestParam("operand1") String x,@RequestParam("operand2") String y,@RequestParam("operator") String z) {
		int i=Integer.parseInt(x);
		int j=Integer.parseInt(y);
		String result=calService.performCalculation(i, j, z);
		if(result.equalsIgnoreCase("ABCD"))
			throw new OperatorException();
		ModelAndView mv=new ModelAndView("calculatorResult");
		mv.addObject("result",result);
		return mv;
	}
    @ExceptionHandler(value = ArithmeticException.class)
	   public ModelAndView handlingArithmeticException(ArithmeticException exception) {
		   String message="Divided by zero not possible";
		   ModelAndView mv=new ModelAndView("errorShow");
		   mv.addObject("errorMessage",message);
		   return mv;
	   }
    @ExceptionHandler(value = NumberFormatException.class)
	   public ModelAndView handlingNumberFormatException(NumberFormatException exception) {
		   String message="Input must be a Whole Number";
		   ModelAndView mv=new ModelAndView("errorShow");
		   mv.addObject("errorMessage",message);
		   return mv;
	   }
    
    @ExceptionHandler(value = OperatorException.class)
	   public ModelAndView handlingOperatorException(OperatorException exception) {
		   String message="Input proper Mathematical Operation";
		   ModelAndView mv=new ModelAndView("errorShow");
		   mv.addObject("errorMessage",message);
		   return mv;
	   }

}//end of CalculatorController Class
