package org.anudip.LabSubmission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabSubmissionApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabSubmissionApplication.class, args);
	}

}
