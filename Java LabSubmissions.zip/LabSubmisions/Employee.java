package org.anudip.LabSubmisions;

//Defining the base class Employee which implements the Comparable interface
class Employee implements Comparable<Employee> {//Start of Employee class
    private String employeeId;// Private member variable to store employee ID
    private String employeeName;// Private member variable to store employee name
    private String department;// Private member variable to store employee department

    // Constructor to initialize employee name and department
    public Employee(String employeeName, String department) {
        this.employeeName = employeeName;
        this.department = department;
    }
    // Getter method to retrieve employee ID
    public String getEmployeeId() {
        return employeeId;
    }
    // Setter method to set employee ID
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
    // Getter method to retrieve employee name
    public String getEmployeeName() {
        return employeeName;
    }
    // Setter method to set employee name
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }
    // Getter method to retrieve employee department
    public String getDepartment() {
        return department;
    }
    // Setter method to set employee department
    public void setDepartment(String department) {
        this.department = department;
    }
    // Declaring a method to calculate tax, to be implemented in subclasses
    public double calculateTax() {
        // To be implemented in subclasses
        return 0;
    }
    // Overriding toString method to format the employee information
    @Override
    public String toString() {
        return String.format("%-10s %-20s %-15s", employeeId, employeeName, department);
    }
    // Implementing the compareTo method for sorting employees by ID
    @Override
    public int compareTo(Employee other) {
        return this.employeeId.compareTo(other.employeeId);
    }
}//End of Employee class
