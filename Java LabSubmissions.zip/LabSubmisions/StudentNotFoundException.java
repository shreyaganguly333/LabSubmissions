package org.anudip.LabSubmisions;
//Declaring the public StudentNotFoundException class
public class StudentNotFoundException extends RuntimeException {
	 //Declaring the SerialVersionUID
    private static final long serialVersionUID = 1L;
    //Declaring the StudentNotFoundException
	public StudentNotFoundException(String message) {
        super(message);
    }//end
}//end of StudentNotFoundException class