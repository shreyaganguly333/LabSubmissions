//WAP in Java to Store the Name of the Customer, Mobile No, the total amount of purchase and the total discount on the purchase
package org.anudip.LabSubmisions;
import java.util.Scanner;
//Declaring Public class
public class ShowRoom {
	//Declaring Private classes
	 private String name;
	    private long mobno;
	    private double cost;
	    private double dis;
	    private double amount;
	    //Default constructor
	    public ShowRoom()
	    //Initialization of Variables
	    {
	        name = "";
	        mobno = 0;
	        cost = 0.0;
	        dis = 0.0;
	        amount = 0.0;
	    }
	    //Taking input from the User
	    public void input() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Hi Customer, Enter your Name: ");
	        name = scanner.nextLine();
	        System.out.print("Enter Your Mobile no: ");
	        mobno = scanner.nextLong();
	        System.out.print("Enter the Total Bill Value: ");
	        cost = scanner.nextDouble();
	        scanner.close();
	    }	    
	    //Using Looping method to calculate the discount on the bill value
	    public void calculate() {
	        int disPercent = 0;
	        if (cost <= 10000)
	            disPercent = 5;
	        else if (cost <= 20000)
	            disPercent = 10;
	        else if (cost <= 35000)
	            disPercent = 15;
	        else
	            disPercent = 20;   
	        dis = cost * disPercent / 100.0;
	        amount = cost - dis;
	    }    
	    //Displaying Customer Details and Total Amount to be paid after Discount
	    public void display() {
	        System.out.println("Customer Name: " + name);
	        System.out.println("Mobile Number: " + mobno);
	        System.out.println("Total Amount to be paid after discount: " + amount);
	    }   
	    //Declaration of Main function
	    public static void main(String args[]) {
	        ShowRoom obj = new ShowRoom();
	        obj.input();
	        obj.calculate();
	        obj.display();
	    }//end of main
	   
}//end of class