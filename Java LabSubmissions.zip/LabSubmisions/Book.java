package org.anudip.LabSubmisions;

import java.util.ArrayList;//Importing ArrayList functions
import java.util.Collections;//Importing Collections Functions
import java.util.Comparator;//Importing Comparator Functions
import java.util.List;//Importing List Functions
import java.util.Scanner;//Importing Scanner to take up input from the user

//Declaring the Book Class
class Book {//start of the Book Class
    private Integer bookNumber;//Declaring Private Integer bookNumber Method
    private String bookTitle;//Declaring Private String bookTitle Method
    private String author;//Declaring Private String author Method
    
    //Implementing Constructors
    public Book(Integer bookNumber, String bookTitle, String author) {
        this.bookNumber = bookNumber;
        this.bookTitle = bookTitle;
        this.author = author;
    }
    //Implementing Getter and Setter methods
    public Integer getBookNumber() {//Getter for BookNumber
        return bookNumber;
    }
    public void setBookNumber(Integer bookNumber) {//Setter for BookNumber
        this.bookNumber = bookNumber;
    }

    public String getBookTitle() {//Getter for BookTitle
        return bookTitle;
    }
    public void setBookTitle(String bookTitle) {//Setter for BookTitle
        this.bookTitle = bookTitle;
    }

    public String getAuthor() {//Getter for Author
        return author;
    }
    public void setAuthor(String author) {//Setter for Author
        this.author = author;
    }
    //Implementing Override method
    @Override
    public String toString() {
    	//Using a specific String format
        return String.format("%-10s %-35s %-20s", bookNumber, bookTitle, author);
    }
}//end of the Book Class