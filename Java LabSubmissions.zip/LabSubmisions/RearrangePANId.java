//Pan card’s id consists of alphanumerical figure. Length is always 10. Alphabets are in capital letters. You are required to accept a Pan card id then arrange the numbers in ascending order on the left hand side and alphabets are in descending order on the right hand side. If any alphabet is in lower case, it will be converted into upper case. Please check input is always alphanumerical figure only i.e no special character, length is always 10.
package org.anudip.LabSubmisions;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

//Declaring of Public class
public class RearrangePANId {
	//Declaring the Validity of Pan Card Number
	public static boolean isValidPanCard(String panCardID) {
        return Pattern.matches("^[A-Z0-9]{10}$", panCardID);
    }
    public static String arrangePanCardID(String panCardID) {
        // Converting any lowercase alphabets to uppercase
        panCardID = panCardID.toUpperCase();
        // Extracting alphabets and numbers separately
        String alphabets = panCardID.replaceAll("[^A-Z]", "");
        String numbers = panCardID.replaceAll("[^0-9]", "");
        // Checking if both alphabets and numbers exist and have a length of 5 characters
        if (alphabets.length() != 5 || numbers.length() != 5) {
            return "Invalid";
        }
        // Converting the numbers part to an array and sort it in ascending order
        char[] numberArray = numbers.toCharArray();
        Arrays.sort(numberArray);
        numbers = new String(numberArray);
        // Converting the alphabets part to an array and sort it in descending order
        char[] alphabetArray = alphabets.toCharArray();
        Arrays.sort(alphabetArray);
        StringBuilder reversedAlphabets = new StringBuilder(new String(alphabetArray));
        reversedAlphabets.reverse();
        alphabets = reversedAlphabets.toString();
        // Combining the sorted numbers and alphabets
        return numbers + alphabets;
    }
    //Declaring the Main function
    public static void main(String[] args) {
    	//Reading the user input
        Scanner scanner = new Scanner(System.in);
        //User Input
        System.out.print("Please Enter your PAN ID: ");
        String panCardID = scanner.nextLine();
        //Looping
        if (isValidPanCard(panCardID)) {
            String arrangedPanCardID = arrangePanCardID(panCardID);
        //Positive Result
            System.out.println("The Arranged PAN ID is: " + arrangedPanCardID);
        } else {
        //Negative Result
            System.out.println("Invalid");
        }
        scanner.close();
    }//end of main
}