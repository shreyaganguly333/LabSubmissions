//Write a Java application that will accept an IP Address. Check that whether it is valid IP address or not. An IP address must have only 4 octets. Each octet consists of a number between 0 to 255. No negative, nor alphanumeric values are present.

package org.anudip.LabSubmisions;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//Declaring the Class
public class IPAddressValidator {
	
	//Declaring the Main Function
    public static void main(String[] args) {
    	//Reading input
        Scanner scanner = new Scanner(System.in);
        //Taking input from the User
        System.out.print("Enter an IP Address: ");
        String ipAddress = scanner.nextLine();
        scanner.close();
        //Looping the input for the output
        if (isValidIPAddress(ipAddress)) {
            System.out.println("Valid");
        } else {
            System.out.println("Invalid");
        }
    }//end of main

    public static boolean isValidIPAddress(String ipAddress) {
        // Regular expression pattern to validate an IP address
        String regex = "^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$";

        // Compile the Regex pattern
        Pattern pattern = Pattern.compile(regex);

        // Create a Matcher object for the input ipAddress
        Matcher matcher = pattern.matcher(ipAddress);

        // Check if the ipAddress matches the regex pattern
        return matcher.matches();
    }
}
