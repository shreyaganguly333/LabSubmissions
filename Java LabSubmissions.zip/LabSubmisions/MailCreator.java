package org.anudip.LabSubmisions;

import java.util.Scanner;

public class MailCreator {
    public static String createMailAccount(String studentName) {
        // Converting the student name to lowercase
        String lowercaseName = studentName.toLowerCase();

        // Replacing spaces with dots
        String formattedName = lowercaseName.replace(" ", ".");

        // Appending "@tsr.edu" to the formatted name
        String mailId = formattedName + "@tsr.edu";

        return mailId;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //Output printing for the Name of the Student
        System.out.print("Hello Student!Enter your name: ");
        String studentName = scanner.nextLine();

        String mailId = createMailAccount(studentName);
        
        //Output printing for the Mail ID of the Student
        System.out.println("Student's mail id: " + mailId);
    }
}
