package org.anudip.LabSubmisions;

import java.util.Scanner;

//Declaring the Applicant Main Class
public class ApplicantMain {
    public static void main(String[] args) {
    	//Scanner Statement to Read User Input
        Scanner scanner = new Scanner(System.in);
        
        //Taking input from the User about the no. of Applicants
        System.out.print("User, Please Enter the Number of Applicants: ");
        int numApplicants = scanner.nextInt();
        scanner.nextLine(); 
        
        //Creating the Array to store Input from User
        Applicant[] applicants = new Applicant[numApplicants];

        // Starting of the For Loop
        for (int i = 0; i < numApplicants; i++) {
            System.out.print("Enter applicant details (Name, Subject1, Subject2, Subject3): ");
            String input = scanner.nextLine();
            String[] details = input.split(",");
            
            //Starting the If Loop
            if (details.length != 4) {
                System.out.println("Invalid input format. Please enter in the correct format.");
                i--;
                continue;
            }//end of If loop
            
            //Performing the Trip Function
            String name = details[0].trim();
            //Trimming Subject1
            int subject1 = Integer.parseInt(details[1].trim());
            //Trimming Subject2
            int subject2 = Integer.parseInt(details[2].trim());
            //Trimming Subject3
            int subject3 = Integer.parseInt(details[3].trim());
            
            //Starting of If loop
            if (subject1 < 0 || subject1 > 100 || subject2 < 0 || subject2 > 100 || subject3 < 0 || subject3 > 100) {
                System.out.println("Invalid marks. Marks should be between 0 and 100 (inclusive).");
                i--;
                continue;
            }//end of If Loop

            Applicant applicant = new Applicant(name, subject1, subject2, subject3);
            int total = Applicant.totalCalculation(applicant); //Declaring the Total Calculation function
            int percentage = Applicant.percentageCalculation(total); //Declaring the Percentage Calculation function

            applicant.setTotal(total);
            applicant.setPercentage(percentage);

            applicants[i] = applicant;
        }//end of For loop

        scanner.close();

        // Displaying passed applicants' details
        System.out.println("\nPassed Applicants:");
        System.out.println(String.format("%-10s %-5s %-5s %-5s %-10s %-10s", "Name", "Sub1", "Sub2", "Sub3", "Total", "Percentage"));
        //Starting of For loop
        for (Applicant applicant : applicants) {
        	//Starting of If loop
            if (applicant.getPercentage() >= 70) {
                System.out.println(applicant);
            }//end of If loop
        }//end of For loop
    }//end of Public static Void main
}//end of Applicant Main