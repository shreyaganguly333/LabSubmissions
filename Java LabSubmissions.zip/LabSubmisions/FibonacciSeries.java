package org.anudip.LabSubmisions;

import java.util.Scanner;

public class FibonacciSeries {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //User input 
        System.out.print("Hi User! Please Enter a number: ");
        int n = scanner.nextInt();

        // Checking if the number is Fibonacci or not
        boolean isFibonacci = isFibonacci(n);

        // Displaying the result
        if (isFibonacci) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }
    }

    // Method to check if a number is Fibonacci or Not
    public static boolean isFibonacci(int n) {
        int a = 0, b = 1;
    //Looping Starts
        while (a <= n) {
            if (a == n) {
                return true;
            }
            
            int temp = a;
            a = b;
            b = temp + b;
        }
      //Looping Ends  
        return false;
    }
}
