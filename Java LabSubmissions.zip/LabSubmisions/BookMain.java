package org.anudip.LabSubmisions;

import java.util.List;//Importing List Functions
import java.util.Scanner;//Importing Scanner to take up input from the user

//Declaring the BookMain Class
public class BookMain {//Start of BookMain class
    public static void main(String[] args) {//Start of Main function
    	// Creating a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);
        // Creating an instance of BookService to manage book-related operations
        BookService bookService = new BookService();
        
        //Using While Looping to present the user with a menu and handle their choices
        while (true) {//Start of While Loop
        	// Displaying the menu options to Choose from
            System.out.println("Menu");
            System.out.println("1. Display Book Number-wise");
            System.out.println("2. Display Book Title-wise");
            System.out.println("3. Display Book Author-wise");
            System.out.println("4. Exit");
            System.out.print("Hi User! Please Enter a Choice from 1-4: ");
            
            // Reading the user's choice
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline
            
            //Using If looping to check the constion if the user chooses to exit (choice 4)
            if (choice == 4) {
                break;
            }
            
            // Retrieving a list of all books from the Library class
            List<Book> books = Library.getAllBooks();
            // Using a switch statement to perform actions based on user's choice
            switch (choice) {//start of Switch Case
                case 1:
                    books = bookService.arrangeBooksNumberWise(books);
                    break;
                case 2:
                    books = bookService.arrangeBooksTitleWise(books);
                    break;
                case 3:
                    books = bookService.arrangeBooksAuthorWise(books);
                    break;
                default:
                    System.out.println("Invalid choice. Please choose again.");
                    continue;
            }//End of Switch Case
            
            // Displaying the sorted list of books in a tabular format
            System.out.println("\nBook Number    Book Title                        Author");
            //Using For looping to display
            for (Book book : books) {//Start of For loop
                System.out.println(book);
            }//End of For loop
            System.out.println();
        }//End of While Loop
        // Display an exit message after the program has been run successfully.
        System.out.println("Application is Done. Goodbye!");
        scanner.close();
    }//End of Main function
}//End of BookMain class
