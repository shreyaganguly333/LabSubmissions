package org.anudip.LabSubmisions;//Importing the Package where the EssentialCommodityException Class exists
//Declaring the public EssentialCommodityException class
public class EssentialCommodityException extends RuntimeException{//start of EssentialCommodityException class
	 //Declaring the SerialVersionUID
	 static final long serialVersionUID=1L;
	 	//Declaring the EssentialCommodityException
	    public EssentialCommodityException(String message) {//start
	    	super(message);
	    }//end

}//end of EssentialCommodityException class