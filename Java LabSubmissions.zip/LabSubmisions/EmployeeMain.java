package org.anudip.LabSubmisions;

import java.util.ArrayList;// Importing ArrayList to use arraylist in the code
import java.util.Collections;// Importing Collections to use collection methods
import java.util.List;// Importing List to use listing functions
import java.util.Scanner;// Importing Scanner to take User data inputs


public class EmployeeMain {//Start of EmployeeMain class
    public static void main(String[] args) {//Start of Void Main method
        Scanner scanner = new Scanner(System.in);
        //Asking for User to input the number of employees
        System.out.print("Hi User! Please Enter the Number of Employees: ");
        int numEmployees = scanner.nextInt();// Reading the number of employees
        scanner.nextLine(); // Initiating newline
        
        // Creating a list for permanent employees
        List<Employee> permanentEmployees = new ArrayList<>();
        // Creating a list for contract employees
        List<Employee> contractEmployees = new ArrayList<>();

        System.out.println("Please Enter the Employee Details Below!");
        //For Loop to input employee details
        for (int i = 0; i < numEmployees; i++) {//Start of For loop
        	// Triming any leading/trailing spaces
            String input = scanner.nextLine().trim(); 
            // Spliting the input using comma
            String[] data = input.split(",");
            
            // Checking if input is for a permanent employee
            if (data.length == 3) { // Start of If loop
                String name = data[0];
                String department = data[1];
                double salary = Double.parseDouble(data[2]);
                permanentEmployees.add(new PermanentEmployee(name, department, salary));
             // Checking if input is for a contract employee
            } else if (data.length == 4) { // Contract Employee
                String name = data[0];
                String department = data[1];
                int period = Integer.parseInt(data[2]);
                double amount = Double.parseDouble(data[3]);
                contractEmployees.add(new ContractEmployee(name, department, period, amount));
            }//End of If-Else Loop
        }//End of For loop
        
        // Displaying permanent employee section header
        System.out.println("\nPermanent Employee List");
        System.out.println("Id                Name          Department       Salary         PF             Tax");
        //Sorting the permanent employee details
        Collections.sort(permanentEmployees);
        // Iterating through permanent employees
        for (Employee employee : permanentEmployees) {//start of for loop
            //checking for permanent employees
        	if (employee instanceof PermanentEmployee) {
                System.out.println(((PermanentEmployee) employee).toString());
            }
        }//end of for loop
        // Displaying contract employee section header
        System.out.println("\nContract Employee List");
        System.out.println("Id               Name           Department     Period            Amount          Tax");
        //sorting the contract employee details
        contractEmployees.sort(Collections.reverseOrder());
        // Iterating through contract employees
        for (Employee employee : contractEmployees) {//start of for loop
            //checking for contract employees
        	if (employee instanceof ContractEmployee) {
                System.out.println(((ContractEmployee) employee).toString());
            }
        }//end of for loop
    scanner.close();
    }//End of Void Main
}//End of EmployeeMain Class
