package org.anudip.LabSubmisions;
//Declaring the StudentResult Class
class StudentResult {//start of the StudentResult Class
    private String rollNumber; //Declaring Private String rollNumber Method
    private String studentName;//Declaring Private String studentName Method
    private Double halfYearlyTotal;//Declaring Private Double halfYearlyTotal Method
    private Double annualTotal;//Declaring Private Double annualTotal Method
    private String grade;//Declaring Private String grade Method

    //Implementing Constructors
    public StudentResult(String rollNumber, String studentName, Double halfYearlyTotal) {
        this.rollNumber = rollNumber;
        this.studentName = studentName;
        this.halfYearlyTotal = halfYearlyTotal;
    }
    //Implementing Getter and Setter methods
    public String getRollNumber() {
        return rollNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public Double getHalfYearlyTotal() {
        return halfYearlyTotal;
    }

    public Double getAnnualTotal() {
        return annualTotal;
    }

    public void setAnnualTotal(Double annualTotal) {
        this.annualTotal = annualTotal;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
    //Implementing Override method
    @Override
    //Declaring the String toString method
    public String toString() {
    	//Using the format for the method
        return String.format("%-5s %-20s %-20s %-20s %-5s",
                             rollNumber, studentName, halfYearlyTotal, annualTotal, grade);
    }//end of String toString method
}//end of the StudentResult Class
