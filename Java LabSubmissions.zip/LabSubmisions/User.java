package org.anudip.LabSubmisions;
//Declaring the User Class
class User {//start of the User Class
    private String userId;//Declaring Private String userId Method
    private String password;//Declaring Private String password Method

    //Implementing Constructors
    public User(String userId, String password) {
        this.userId = userId;
        this.password = password;
    }
    //Implementing Getter and Setter methods
    public String getUserId() {//Getter for UserId
        return userId;
    }
    public void setUserId(String userId) {//Setter for UserId
        this.userId = userId;
    }
    public String getPassword() {//Getter for Password
        return password;
    }
    public void setPassword(String password) {//Setter for Password
        this.password = password;
    }
}//end of User Class
