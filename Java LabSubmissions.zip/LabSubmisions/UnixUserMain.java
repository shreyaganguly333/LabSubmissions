package org.anudip.LabSubmisions;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

//Declaring Class UnixUserMain for managing Unix user creation and display.
public class UnixUserMain {
	
	// Static variables to keep track of super and ordinary user counts.
    private static int superUserCount = 0;
    private static int ordinaryUserCount = 0;
    
    // Method to check if a number is prime.
    public static boolean checkPrime(int no) {
        if (no <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(no); i++) {
            if (no % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    // Main method for user input, creation, and display.
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Hello User Please Enter the Number of Users Id/s to be Created:");
        int numUsers = scanner.nextInt();
        scanner.nextLine(); 
        
        // Using LinkedHashSet to calculate
        Set<UnixUser> unixUsers = new LinkedHashSet<>(); 
        
        // Loop to gather user details and create UnixUser objects.
        for (int i = 0; i < numUsers; i++) {
            System.out.println("Hi User! Please Enter User Details in the format Employee Id, Name, User type):");
            String[] userDetails = scanner.nextLine().split(",");
            int employeeId = Integer.parseInt(userDetails[0]);
            String username = userDetails[1];
            String userType = userDetails[2];
            int userId = generateUserId(userType);
            unixUsers.add(new UnixUser(userId, employeeId, username, userType));
        }//end of for loop
        scanner.close();

        // Displaying the Unix users in tabular format
        System.out.println("\nUser Id    Employee Id     User Name            User Type");
        unixUsers.forEach(user -> System.out.println(user.toString()));
    }//end of main

    // Method to generate a unique user ID based on user type.
    private static int generateUserId(String userType) {
        int userId;
        if (userType.equals("Super")) {
            userId = 1013 + superUserCount++;
        } else {
            userId = 1001 + ordinaryUserCount++;
        }
        return userId;
    }//end of private class generateUserId
}//end of UnixUserMain Class