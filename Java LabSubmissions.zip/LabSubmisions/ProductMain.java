package org.anudip.LabSubmisions;//Importing the Package where the ProductMain Class exists
import java.util.Scanner;//Importing the Package for enabling data collection from User
//Declaring the ProductMain Class
public class ProductMain {//start of ProductMain class
	//Declaring the Public Static Void Main class
	public static void main(String[] args) {//start of the Public Static Void Main class
		 //Scanner Statement to Read User Input
		 Scanner scanner =new Scanner(System.in);
		 // Accepting the Number of Products from the User
		 System.out.println("Hi User! Please Enter the Number of Products: ");
		 //Parsing the Integer number value
		 int number=Integer.parseInt(scanner.nextLine());
		 //Creating the Product Array to store the Number
		 Product []productArr=new Product[number];
		 int length=productArr.length;
		 
		 // Accepting the The Details of the Product from the User
		 System.out.println("Please Enter all the Products with their Details in this format(ID,Name,Purchased Price,Sales Price,Grade):");
		//Using For looping for Condition 1
		 for(int i=0; i<length;i++) { //start of for looping
			 // Accepting the Product from the User
			 System.out.println("Please, Enter Product "+(i+1)+":");
			 String product=scanner.nextLine();
			 //Creating the splitting of the input with a comma
			 String []arr=product.split(",");
			 //Storing User given "ID" at Array index 0
			 int id=Integer.parseInt(arr[0]);
			 //Storing User given "Name" at Array index 1
			 String name=arr[1];
			 //Storing User given "purchasedPrice" at Array index 2
			 double purchasedPrice=Double.parseDouble(arr[2]);
			 //Storing User given "salesPrice" at Array index 3
			 double salesPrice=Double.parseDouble(arr[3]);
			 //Storing User given "grade" at Array index 4
			 String grade =arr[4];
			 //Declaring new variables with String values "E" and "N" and products
			 String eCarry="E";
			 String nCarry="N";
			 Product products=new Product();
			 try {//start of try block
			 //Checking Sales price & Purchase Price using If looping, if yes then throwing an Exception
			 if(salesPrice<purchasedPrice) {//start of If looping block
				 throw new PriceException("Oh no! Sales Price must be Higher than Purchase price");
			 }//end of If looping block
			 //Using Else If looping Checking whether the product grade is wrong if yes then throwing an Exception
			 else if(!(grade.equals(eCarry)|| grade.equals(nCarry))) {//start of If-Else looping block
				 throw new GradeMismatchException("Alas! Wrong grade");
			 }//End of If-Else looping block
			 //Using Else-If looping checking whether E graded product sales price is greater than 25% of purchase price if yes then throwing an Exeption
			 else if(grade.equals(eCarry)&&(salesPrice>purchasedPrice+(0.25*purchasedPrice))) {//start of If-Else looping block
				 throw new EssentialCommodityException("Sorry! E Graded items Sales price must be lesser than 25% of Purchase Price");
			 }//end of If-Else looping block
			 //Using Else looping block setting all values of products
			 else {//start of else looping block
				 products.setId(id);
				 products.setName(name);
				 products.setPurchasedPrice(purchasedPrice);
				 products.setSalesPrice(salesPrice);
				 products.setGrade(grade);
			 }//end of else looping block
		}//end of try block
	     catch(PriceException pe) {//start of catch block
			 System.out.println("PriceException : "+pe.getMessage());
		 }//end of catch block
        catch(EssentialCommodityException ece) {//start of catch block
       	 System.out.println("EssentialCommodityException : "+ece.getMessage());
        }//end of catch block
		catch(GradeMismatchException ge) {//start of catch block
	        	 System.out.println("GradeMismatchException : "+ge.getMessage());
	    }//end of catch block
		   
		   productArr[i]=products;
		   
		 }//end of for loop
		//Printing the output in the given String format	    
		System.out.println(String.format("%-5s %-20s %-10s %-10s %-5s","id","name","CostPrice","salesPrice","grade"));
		
		//Displaying all products using For looping block
		for(Product p:productArr) {//start of for looping block
			System.out.println(p);
		}//end of for looping block
		//Printing to make sure that the Program has run all the loop and is at the end of the program
		System.out.println("The program is over");
		scanner.close();//closing the scanner class
	}//end of the Public Static Void Main class

}//end of ProductMain class