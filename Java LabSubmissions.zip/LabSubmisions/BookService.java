package org.anudip.LabSubmisions;

import java.util.Collections;//Importing Collections Functions
import java.util.Comparator;//Importing Comparator Functions
import java.util.List;//Importing List Functions

//Declaring the BookService Class
class BookService {//Start of BookService Class
	// Method to arrange books in the bookList by book number
    public List<Book> arrangeBooksNumberWise(List<Book> bookList) {//Start of the arrangeBooksNumberWise method
    	// Use Collections.sort to sort the bookList based on book numbers using a comparator
        Collections.sort(bookList, Comparator.comparing(Book::getBookNumber));
        // Returning the sorted bookList
        return bookList;
    }//End of the arrangeBooksNumberWise method
    
    // Method to arrange books in the bookList by book title
    public List<Book> arrangeBooksTitleWise(List<Book> bookList) {//Start of the arrangeBooksTitleWise method
    	// Using Collections.sort to sort the bookList based on book titles using a comparator
    	Collections.sort(bookList, Comparator.comparing(Book::getBookTitle));
    	// Returning the sorted bookList
    	return bookList;
    }//End of the arrangeBooksTitleWise method
    
    // Method to arrange books in the bookList by author's name
    public List<Book> arrangeBooksAuthorWise(List<Book> bookList) {//Start of the arrangeBooksAuthorWise method
    	// Using Collections.sort to sort the bookList based on author names using a comparator
    	Collections.sort(bookList, Comparator.comparing(Book::getAuthor));
        // Returning the sorted bookList
        return bookList;
    }//End of the arrangeBooksAuthorWise method
}//End of BookService Class
