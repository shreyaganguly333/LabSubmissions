package org.anudip.LabSubmisions;//Importing the Package where the WageException Class exists

//Declaring the public WageException class
public class WageException extends RuntimeException {//start of WageException class
		//Declaring the SerialVersionUID
		static final long serialVersionUID = 5L;
		//Declaring the WageException
		public WageException(String message) {//start
	        super(message);
	    }//end

}//end of WageException class


