package org.anudip.LabSubmisions;
import java.util.Scanner;
//Declaring public class FactorialChecker
public class FactorialChecker {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	      //Asking User to give a Number to be checked
	        System.out.print("Hi User! Please give a Enter a Number: ");
	        int number = scanner.nextInt();
	        scanner.close();
	        //Using If looping to check whether the number is factorial or not.
	        if (isFactorialNumber(number)) {
	            System.out.println("yes");
	        } else {
	            System.out.println("No");
	        }//end of else1
	    }//end of void main
	    //Declaring isFactorialNumber 
	    static boolean isFactorialNumber(int number1) {
	        int factorial = 1;
	        int number2 = 1;
	        //Using the While looping to calculate the factorial 
	        while (factorial < number1) {
	            number2++;
	            factorial *= number2;
	        }//end of while
	        return factorial == number1;
    }//end of main
}//end of FactorialChecker class