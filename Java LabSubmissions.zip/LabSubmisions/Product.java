package org.anudip.LabSubmisions;//Importing the Package where the Product Class exists
////Declaring the Product Class
public class Product {//start of Product Class
    private Integer id;//Declaring Private Integer id Method
    private String name;//Declaring Private String name Method
    private Double purchasedPrice;//Declaring Private Double purchasedPrice Method
    private Double salesPrice;//Declaring Private Double salesPrice Method
    private String grade;//Declaring Private String grade Method
    
    // Getters and setters
    public Integer getId() {//Getter for Id
	     return id;
    }
    public void setId(Integer id) {//Setter for Id
	     this.id = id;//constructor for id
    }
    public String getName() {//Getter for Name
	     return name;
    }
    public void setName(String name) {//Setter for name
	     this.name = name;//constructor for name
    }
    public Double getPurchasedPrice() {//Getter for PurchasedPrice
	     return purchasedPrice;
    }
    public void setPurchasedPrice(Double purchasedPrice) {//Setter for PurchasedPrice
	       this.purchasedPrice = purchasedPrice;//constructor for PurchasedPrice
    }
    public Double getSalesPrice() {//Getter for SalesPrice
	       return salesPrice;
    }
    public void setSalesPrice(Double salesPrice) {//Setter for SalesPrice
	       this.salesPrice = salesPrice;//constructor for SalesPrice
    }
    public String getGrade() {//Getter for Grade
	        return grade;
    }
    public void setGrade(String grade) {//Setter for Grade
	        this.grade = grade;//constructor for Grade
    }
    @Override
    public String toString() {//Start of the String toString format
    	 //Specifying the string format
	     String output=String.format("%-5s %-20s %-10s %-10s %-5s",id,name,purchasedPrice,salesPrice,grade);
	     return  output;
    }//end of the String toString format
 
}//end of Product Class