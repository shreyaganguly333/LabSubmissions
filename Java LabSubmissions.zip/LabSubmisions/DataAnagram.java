package org.anudip.LabSubmisions;

import java.util.Arrays;
import java.util.Scanner;

public class DataAnagram {
    public static boolean checkAnagram(String string1, String string2) {
        // Removing all whitespaces and converting both strings to lowercase
        string1 = string1.replaceAll("\\s", "").toLowerCase();
        string2 = string2.replaceAll("\\s", "").toLowerCase();

        // Checking if the lengths of the two strings are equal
        if (string1.length() != string2.length()) {
            return false;
        }

        // Converting strings to character arrays
        char[] charArray1 = string1.toCharArray();
        char[] charArray2 = string2.toCharArray();

        // Sorting the character arrays
        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        // Comparing the sorted character arrays
        return Arrays.equals(charArray1, charArray2);
    }
    	//Main function
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //Asking for the 1st output from the User
        System.out.print("User! Please, Enter the First String: ");
        String string1 = scanner.nextLine();
        
       //Asking for the 2nd output from the User
        System.out.print("User! Please, Enter the Second String: ");
        String string2 = scanner.nextLine();
        
       //Checking whether the strings provided by user is a Anagram or not
        boolean isAnagram = checkAnagram(string1, string2);
        
        //Looping
        if (isAnagram) {
            System.out.println("Congratulations!The Strings are Anagrams."); //Output Case 1
        } else {
            System.out.println("Oh! No! The Strings are not Anagrams."); //Output Case 2
        }
    }
}
