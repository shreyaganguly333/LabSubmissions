package org.anudip.LabSubmisions;//Importing the Package where the EmployeeWage Class exists
import java.text.DecimalFormat;//Importing the Package for enabling DecimalFormat
import java.util.Scanner;//Importing the Package for enabling data collection from User
//Declaring the EmployeeWage Class
public class EmployeeWage { //start of EmployeeWage class
	//Declaring the Decimal Format to a variable
    private static DecimalFormat decimalFormat = new DecimalFormat("0.00");
    //Declaring the convertToTwoDecimalPlace Class
    public static String convertToTwoDecimalPlace(double value) {//start of convertToTwoDecimalPlace Class
    	//Returning the value of Decimal format
        return decimalFormat.format(value);
    }//end of convertToTwoDecimalPlace Class
    
    //Declaring the Public Static Void Main class
    public static void main(String[] args) {//start of the Public Static Void Main class
    	//Scanner Statement to Read User Input
    	Scanner scanner = new Scanner(System.in);
        try {//start of Try block 1
            int numWorkers;

            // Accepting the number of workers from the User
            System.out.print("Hi User! Please Enter the number of workers at the Site (Give minimum of 5): ");
            numWorkers = Integer.parseInt(scanner.nextLine());
            //Looping for Condition 1
            if (numWorkers < 5) {
            	//Output of Condition 1
                System.out.println("Uh no! Wrong Worker number. Program Stopped.Let's try again");
                return;
            }//end of If loop
            
            //Setting the initial value of totalWage as zero
            double totalWage = 0;
            //Using For looping for Condition 2
            for (int i = 0; i < numWorkers; i++) { //start of for looping
                // Accepting the wage figure of each worker
                while (true) { //start of While looping
                    try {//start of try block 2
                    	// Accepting the the daily wage of worker from the User
                    	System.out.print("User Please, Enter the daily Wage of Worker " + (i + 1) + ": ");
                        double wage = Double.parseDouble(scanner.nextLine());
                        //Using If looping for Condition 3
                        if (wage < 100.00 || wage > 250.00) {
                            throw new WageException("WageException: Wage should be between 100.00 and 250.00");
                        }//end of if loop
                        
                        //Calculating the totalWage
                        totalWage += wage;
                        break;//to get out of the loop
                    //end of try block 2 
                    } catch (NumberFormatException ex) { //start of catch block 1
                        System.out.println("Wrong Input! Please Enter a Valid Number.");
                    //end of catch block 1
                    } catch (WageException ex) { //start of catch block 2
                        System.out.println(ex.getMessage());
                    }//end of catch block 2
                }//end of While looping
            }//end of for looping

            // Calculating the average wage
            double averageWage = totalWage / numWorkers;

            // Displaying the total and average wage for the site
            System.out.println("Total Wage is: Rs." + convertToTwoDecimalPlace(totalWage));
            System.out.println("Average Daily Wage is: Rs." + convertToTwoDecimalPlace(averageWage));
        //end of Try block 1
        } finally { //start of finally block 
        	//Printing to make sure that the Program has run all the loop and is at the end of the program
            System.out.println("The Application is over.");
        scanner.close();//closing the scanner class
        }//end of finally block
    }//end of the Public Static Void Main class
}//end of EmployeeWage class