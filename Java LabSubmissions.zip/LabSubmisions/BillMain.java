package org.anudip.LabSubmisions;

import java.util.Scanner;

//Declaring the Bill Main Class
class BillMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //Asking User to give the No.of Consumers
        System.out.print("Hi User! Enter the Number of Consumers: ");
        int numConsumers = scanner.nextInt();
        
        //If Looping starts
        if (numConsumers <= 0) {
        	//Printing Invalid Input when users give no. of consumers<=0
            System.out.println("Uh No! It's an Invalid Input.");
            scanner.close();
            return;
        }//end of if statement
        
        //Creating the Array to store the Data
        Consumer[] consumers = new Consumer[numConsumers];

        for (int i = 0; i < numConsumers; i++) { //For Looping starts
        	//Asking User to give the Input for ID,Name and Amount Consumed
            System.out.print("User, please Enter details of Consumer Number " + (i + 1) + " (ID,Name,Unit Consumed): ");
            String input = scanner.next();
            //Separating the data with a Comma
            String[] details = input.split(",");
            String id = details[0];
            String name = details[1];
            int unitConsumed = Integer.parseInt(details[2]);
            consumers[i] = new Consumer(id, name, unitConsumed);
        }
        //Printing the Final Bill Details
        System.out.println("\nBill Details:");
        System.out.println("ID    Name                 Unit      Amount");
        System.out.println("--------------------------------------------");
        
        //Starting of For Loop
        for (Consumer consumer : consumers) {
            String finalPayment = BillService.billCalculation(consumer);
            System.out.println(consumer);
        }//end of for loop

        scanner.close();
    }//end of Public Static Void Main
}//end of Bill Main
