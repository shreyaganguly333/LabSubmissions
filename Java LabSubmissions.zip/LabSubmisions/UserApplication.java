package org.anudip.LabSubmisions;

import java.io.BufferedReader;//Importing the IO Buffered Reader Package for  input stream reading and efficient buffering of characters. 
import java.io.FileReader;//Importing the IO FileReader Package to read the input file.
import java.io.IOException;//Importing the IO Exception Package for handling input/output exceptions
import java.util.ArrayList;//Importing ArrayList functions
import java.util.List;//Importing List Functions
import java.util.Scanner;//Importing Scanner to take up input from the user

//Declaring the UserApplication Class
class UserApplication {//start of UserApplication Class
	//Declaring a list to store User objects
    private List<User> userList = new ArrayList<>();
    
    // Method to read user data from a file and populate the userList
    public void uploadToList() {
        //Start of the Try block
    	try (BufferedReader reader = new BufferedReader(new FileReader("d:/UserMaster.txt"))) {
            String line;
            //Using the While looping to split the line with a comma
            while ((line = reader.readLine()) != null) {//start of while loop
                String[] parts = line.split(",");
                // Checking with if looping whether the line contains both user ID and password
                if (parts.length == 2) {//start of if loop
                	// Extracting user ID and password, and adding a new User object to the list
                    String userId = parts[0].trim();
                    String password = parts[1].trim();
                    userList.add(new User(userId, password));
                }//end of if loop
            }//end of while loop
        //catch block to end the try block
        } catch (IOException e) {
        	// Printing the stack trace if an exception occurs during file reading
            e.printStackTrace();
        }//end of catch block
    }//end of uploadToList method
    
    // Method to check if a given user ID and password are valid
    public boolean isValidUser(String userId, String password) {//start of method isValidUser
        //Using For looping
    	for (User user : userList) {//start of for loop
            //Comparing the user ID and password with the .txt user information
    		if (user.getUserId().equals(userId) && user.getPassword().equals(password)) {//start of if loop
                return true;
            }//end of if loop
        }//end of for loop
        return false;//Returning false is the user is not valid
    }//end of method isValidUser

    // Main method to run the user authentication process
    public static void main(String[] args) {//start of main method
    	// Creating an instance of UserApplication
        UserApplication userApp = new UserApplication();
        // Populating the userList by reading user data from a file
        userApp.uploadToList();
        // Creating a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);
        
        //Taking user input for the User ID and Password
        System.out.println("Hi User! Please Enter the User Id:");
        String userId = scanner.nextLine();

        System.out.println("Please give in the Password:");
        String password = scanner.nextLine();
        
        //Using If loop to generate whether the user input is true or false
        if (userApp.isValidUser(userId, password)) {//start of if loop
            System.out.println("Congratulations! It is a Valid User");
        } else {
            System.out.println("Oh no! It is an Invalid User");
        }//end of else loop

        scanner.close();
    }//end of main method
}//end of UserApplication Class