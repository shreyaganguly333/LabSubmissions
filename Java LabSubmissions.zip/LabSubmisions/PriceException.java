package org.anudip.LabSubmisions;//Importing the Package where the PriceException Class exists
//Declaring the public PriceException class
public class PriceException extends RuntimeException{//start of PriceException class
	//Declaring the SerialVersionUID
	static final long serialVersionUID=1L;
	//Declaring the PriceException
    public PriceException(String message) {//start
    	super(message);
    }//end

}//end of PriceException class