package org.anudip.LabSubmisions;//Importing the Package where the GradeMismatchException Class exists
//Declaring the public GradeMismatchException class
public class GradeMismatchException extends RuntimeException{//start of GradeMismatchException
	//Declaring the SerialVersionUID
	static final long serialVersionUID=1L;
		//Declaring the GradeMismatchException
	    public GradeMismatchException(String message) {//start
	    	super(message);
	    }//end

}//end of GradeMismatchException