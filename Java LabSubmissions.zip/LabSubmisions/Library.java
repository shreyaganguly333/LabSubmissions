package org.anudip.LabSubmisions;

import java.util.ArrayList;//Importing ArrayList functions
import java.util.List;//Importing List Functions
//Declaring the Library Class
class Library {//Start of the Library Class
	// Declaring a static list to store Book objects
    private static List<Book> bookList = new ArrayList<>();
    // Static initializer block, runs when the class is loaded
    static {//start of the static block
    	// Adding predefined Book objects to the bookList
        bookList.add(new Book(10001, "Anna Karenina", "Tolstoy"));
        bookList.add(new Book(10002, "Song Offerings", "Tagore"));
        bookList.add(new Book(10003, "Tempest", "Shakespeare"));
        bookList.add(new Book(10004, "Macbeth", "Shakespeare"));
        bookList.add(new Book(10005, "Gora", "Tagore"));
        bookList.add(new Book(10006, "War And Peace", "Tolstoy"));
        bookList.add(new Book(10007, "Hamlet", "Shakespeare"));
        bookList.add(new Book(10008, "Adventure of Holme", "Doyle"));
        bookList.add(new Book(10009, "Red Oleanders", "Tagore"));
        bookList.add(new Book(10010, "Hound of Baskerville", "Doyle"));
    }//end of the static block
    // Declaring the Public static method to retrieve all books in the library
    public static List<Book> getAllBooks() {//Start of Public static method
        //Returning booklist values
    	return bookList;
    }//end of public static method
}//End of the Library Class
