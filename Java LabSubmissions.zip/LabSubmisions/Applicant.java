package org.anudip.LabSubmisions;

import java.util.Scanner;

//Declaring the Applicant Class
class Applicant {
    private String name;//Declaring Private String Name Method
    private Integer subject1;//Declaring Private Integer Subject 1 Method
    private Integer subject2;//Declaring Private Integer Subject 2 Method
    private Integer subject3;//Declaring Private Integer Subject 3 Method
    private Integer total;//Declaring Private Integer Total Method
    private Integer percentage;//Declaring Private Integer Percentage Method
    
    // Constructors
    public Applicant(String name, Integer subject1, Integer subject2, Integer subject3) {
        this.name = name;
        this.subject1 = subject1;
        this.subject2 = subject2;
        this.subject3 = subject3;
        this.total = 0;
        this.percentage = 0;
    }//end of Constructors

    // Getters and Setters
    public String getName() {//Getter for Name
        return name;
    }

    public void setName(String name) {//Setter for Name
        this.name = name;
    }

    public Integer getSubject1() {//Getter for Subject1
        return subject1;
    }

    public void setSubject1(Integer subject1) {//Setter for Subject1
        this.subject1 = subject1;
    }

    public Integer getSubject2() {//Getter for Subject2
        return subject2;
    }

    public void setSubject2(Integer subject2) {//Setter for Subject2
        this.subject2 = subject2;
    }

    public Integer getSubject3() {//Getter for Subject3
        return subject3;
    }

    public void setSubject3(Integer subject3) {//Setter for Subject3
        this.subject3 = subject3;
    }

    public Integer getTotal() {//Getter for Total
        return total;
    }

    public void setTotal(Integer total) {//Setter for Total
        this.total = total;
    }

    public Integer getPercentage() {//Getter for Percentage
        return percentage;
    }

    public void setPercentage(Integer percentage) {//Setter for Percentage
        this.percentage = percentage;
    }

    // Method to calculate total marks and return 0 if any subject's mark is below 50
    public static int totalCalculation(Applicant applicant) {
        //Starting of the If Looping
    	if (applicant.getSubject1() < 50 || applicant.getSubject2() < 50 || applicant.getSubject3() < 50) {
            return 0;
        }//end of If loop
        return applicant.getSubject1() + applicant.getSubject2() + applicant.getSubject3();
    }//end of Public Static Total Calculation

    // Method to calculate percentage
    public static int percentageCalculation(int total) {
        return (total * 100) / 300;
    }//end of Public Static Percentage Calculation

    @Override
    public String toString() {//Using the String to String format
        return String.format("%-10s %-5s %-5s %-5s %-10s %-10s",
                name, subject1, subject2, subject3, total, percentage);
    }//end of String toString Method
}//end of Main method